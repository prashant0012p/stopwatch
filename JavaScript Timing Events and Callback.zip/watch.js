window.onload = function () {


    var minutes = 00;
    var seconds = 00;
    var milliseconds = 00;
    var appendSeconds = document.getElementById("sec");
    var appendMinutes = document.getElementById("min");
    var appendMilliseconds = document.getElementById("milli");
    var buttonStart = document.getElementById('Start');
    var buttonStop = document.getElementById('Stop');
    var buttonReset = document.getElementById('Reset');
    var Interval;



    buttonStart.onclick = function () {
        clearInterval(Interval);
        Interval = setInterval(startTimer, 10);
    }

    buttonStop.onclick = function () {
        clearInterval(Interval);
    }

    buttonReset.onclick = function () {
        clearInterval(Interval);
         minutes = "00";
        seconds = "00";
        milliseconds = "00";
        appendSeconds.innerHTML = seconds ;
        appendMinutes.innerHTML = minutes;
        appendMilliseconds.innerHTML = milliseconds;

    }



    function startTimer() {
        milliseconds++
        
        if(milliseconds <= 9){
         appendMilliseconds.innerHTML = "0"+milliseconds

        }
        if(milliseconds >9){
         appendMilliseconds.innerHTML = milliseconds

        }
        if(milliseconds > 99){
   
            seconds++;
            appendSeconds.innerHTML = "0"+seconds;
            milliseconds = 0;
            appendMilliseconds.innerHTML ="0" + milliseconds
                    

        }


       

        if (seconds > 9) {
            appendSeconds.innerHTML =  seconds;
        }
       

        if (seconds > 59) {
            minutes++;
            appendMinutes.innerHTML = "0" + minutes;
            seconds = 0;
            appendSeconds.innerHTML = "0" + seconds
          
        }

        if (minutes > 9) {
            appendMinutes.innerHTML = minutes;
        }

    }



}